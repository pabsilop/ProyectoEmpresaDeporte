package com.salesianos.dam.proyectofinalPabloSilvaLopez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalPabloSilvaLopezApplicationTests {

	@Test
	void contextLoads() {
	}

}
