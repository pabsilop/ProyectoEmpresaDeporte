package com.salesianos.dam.proyectofinalPabloSilvaLopez.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TarifasController {
	
	@GetMapping({"tarifas.html","/tarifas"})
	public String paginaTarifas() {
		return "tarifas";
	}
}