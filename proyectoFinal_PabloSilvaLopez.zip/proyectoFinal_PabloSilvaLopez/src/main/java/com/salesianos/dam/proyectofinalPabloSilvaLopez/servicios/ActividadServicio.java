package com.salesianos.dam.proyectofinalPabloSilvaLopez.servicios;

import org.springframework.stereotype.Service;

import com.salesianos.dam.proyectofinalPabloSilvaLopez.modelo.Actividad;
import com.salesianos.dam.proyectofinalPabloSilvaLopez.repositorios.ActividadRepository;

@Service
public class ActividadServicio extends BaseService<Actividad, Long, ActividadRepository>{
	public ActividadServicio(ActividadRepository repositorio) {
		super(repositorio);
	}

}
