package com.salesianos.dam.proyectofinalPabloSilvaLopez.controladores;


import org.springframework.web.bind.annotation.GetMapping;

public class RegistroController {
	
	@GetMapping({"registro.html","/registro"})
	public String paginaRegistro() {
		return "registro";
	}
	
	
}