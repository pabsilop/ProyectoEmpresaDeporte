package com.salesianos.dam.proyectofinalPabloSilvaLopez.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CalendarioController {
	
	@GetMapping({"calendario.html","/calendario"})
	public String paginaCalendario() {
		return "calendario";
	}
}