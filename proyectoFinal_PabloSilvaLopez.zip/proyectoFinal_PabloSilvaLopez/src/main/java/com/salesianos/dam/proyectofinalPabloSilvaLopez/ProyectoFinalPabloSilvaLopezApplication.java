package com.salesianos.dam.proyectofinalPabloSilvaLopez;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.salesianos.dam.proyectofinalPabloSilvaLopez.modelo.Usuario;
import com.salesianos.dam.proyectofinalPabloSilvaLopez.servicios.ActividadServicio;
import com.salesianos.dam.proyectofinalPabloSilvaLopez.servicios.UsuarioServicio;

@SpringBootApplication
public class ProyectoFinalPabloSilvaLopezApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFinalPabloSilvaLopezApplication.class, args);
	}

	@Bean
	public CommandLineRunner testDB(UsuarioServicio servicio, ActividadServicio servicioA, BCryptPasswordEncoder passwordEncoder) {
		return new CommandLineRunner() {
			
			@Override
			public void run(String... args) throws Exception {
				// TODO Auto-generated method stub
				
				Usuario u = new Usuario();
				u.setEsAdmin(false);
				u.setNombre("Luis Miguel");
				u.setApellidos("López");
				u.setEmail("luismi.lopez@email.com");
				u.setPassword(passwordEncoder.encode("1234"));
				
				servicio.save(u);
				
				
				Usuario a = new Usuario();
				a.setEsAdmin(true);
				a.setNombre("Ángel");
				a.setApellidos("Narajo");
				a.setEmail("angel.naranjo@email.com");
				a.setPassword(passwordEncoder.encode("1234"));
				
				servicio.save(a);
				
				
			}
		};
	}
}
