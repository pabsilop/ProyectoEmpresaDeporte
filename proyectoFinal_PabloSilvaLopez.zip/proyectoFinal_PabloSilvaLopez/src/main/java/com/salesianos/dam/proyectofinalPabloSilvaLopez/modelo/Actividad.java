package com.salesianos.dam.proyectofinalPabloSilvaLopez.modelo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor
@Entity
public class Actividad {

	@Id @GeneratedValue
	private long id;
	
	private String nombreActividad, monitor;
	private double precio;
	
	@OneToMany(mappedBy="actividad", fetch = FetchType.EAGER)
	private List<Usuario> usuarios = new ArrayList<>();
	
	public void addUsuario(Usuario u) {
		this.usuarios.add(u);
		u.setActividad(this);
	}
	
	public void removeUsuario(Usuario u) {
		this.usuarios.remove(u);
		u.setActividad(null);
	}
	
	public Actividad(String nombreActividad, String monitor, double precio) {
		super();
		this.nombreActividad = nombreActividad;
		this.monitor = monitor;
		this.precio = precio;
	}
	
	
}
