package com.salesianos.dam.proyectofinalPabloSilvaLopez.servicios;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.salesianos.dam.proyectofinalPabloSilvaLopez.modelo.Usuario;
import com.salesianos.dam.proyectofinalPabloSilvaLopez.repositorios.UsuarioRepository;

@Service
public class UsuarioServicio extends BaseService<Usuario, Long, UsuarioRepository>{

	public UsuarioServicio(UsuarioRepository repositorio) {
		super(repositorio);
	}
	
	public Optional<Usuario> buscarPorEmail(String email) {
		return repositorio.findFirstByEmail(email);
	}

}
