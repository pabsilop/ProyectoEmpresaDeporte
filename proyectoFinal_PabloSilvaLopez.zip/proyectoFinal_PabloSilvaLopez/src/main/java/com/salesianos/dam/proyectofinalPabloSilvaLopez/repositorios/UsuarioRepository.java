package com.salesianos.dam.proyectofinalPabloSilvaLopez.repositorios;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianos.dam.proyectofinalPabloSilvaLopez.modelo.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
	Optional<Usuario> findFirstByEmail(String email);
}	
