package com.salesianos.dam.proyectofinalPabloSilvaLopez.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.salesianos.dam.proyectofinalPabloSilvaLopez.modelo.Actividad;

public interface ActividadRepository extends JpaRepository<Actividad, Long>{

}
